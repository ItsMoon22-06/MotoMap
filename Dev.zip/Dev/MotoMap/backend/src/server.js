require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./db');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

// Registro simple de peticiones
app.use((req, _res, next) => {
  console.log(`${new Date().toISOString()}  ${req.method} ${req.originalUrl}`);
  next();
});

// Comprueba servidor + base de datos + PostGIS
app.get('/health', async (_req, res) => {
  try {
    const { rows } = await pool.query('SELECT PostGIS_Version() AS postgis, NOW() AS hora');
    res.json({ estado: 'ok', ...rows[0] });
  } catch (err) {
    res.status(500).json({ estado: 'error', detalle: err.message });
  }
});

app.use('/api/v1', routes);

app.use((_req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error('Error:', err.message);
  res.status(500).json({ error: 'Error interno del servidor' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`MotoMap API escuchando en http://localhost:${PORT}`);
  console.log(`Prueba: http://localhost:${PORT}/health`);
});
