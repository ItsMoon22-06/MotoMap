require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    'postgres://postgres:motomap1234@localhost:5432/motomap',
  max: 10,
});

pool.on('error', (err) => console.error('Error inesperado en el pool de PostgreSQL:', err.message));

module.exports = pool;
