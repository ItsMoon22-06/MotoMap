const express = require('express');
const pool = require('./db');

const router = express.Router();

const RADIO_DEFECTO_M = 5000;
const RADIO_MAX_M = 50000;
const LIMITE = 100;
const TIPOS_MOTOR = ['COMBUSTION', 'ELECTRICA', 'AMBOS'];

// ---------- utilidades de validación ----------
function leerGeo(query) {
  const lat = parseFloat(query.lat);
  const lng = parseFloat(query.lng);
  if (!Number.isFinite(lat) || lat < -90 || lat > 90 ||
      !Number.isFinite(lng) || lng < -180 || lng > 180) {
    return { error: 'Los parámetros lat y lng son obligatorios y deben ser coordenadas válidas' };
  }
  let radio = parseInt(query.radio_m, 10);
  if (!Number.isFinite(radio) || radio <= 0) radio = RADIO_DEFECTO_M;
  radio = Math.min(radio, RADIO_MAX_M);
  return { lat, lng, radio };
}

function numeroOpcional(valor) {
  if (valor === undefined || valor === '') return { valor: null };
  const n = Number(valor);
  return Number.isFinite(n) && n >= 0 ? { valor: n } : { error: true };
}

function textoOpcional(valor) {
  if (valor === undefined) return null;
  const t = String(valor).trim();
  return t === '' ? null : t;
}

// Punto de referencia del usuario, reutilizado en todas las consultas ($1=lng, $2=lat)
const PUNTO = 'ST_SetSRID(ST_MakePoint($1::float8, $2::float8), 4326)::geography';

// ---------- GET /api/v1/estaciones-gasolina ----------
router.get('/estaciones-gasolina', async (req, res, next) => {
  try {
    const geo = leerGeo(req.query);
    if (geo.error) return res.status(400).json({ error: geo.error });
    const precio = numeroOpcional(req.query.precio_max);
    if (precio.error) return res.status(400).json({ error: 'precio_max debe ser un número positivo' });

    const sql = `
      SELECT id::int AS id,
             'ESTACION_GASOLINA'              AS tipo,
             nombre, direccion,
             ST_Y(ubicacion)                  AS latitud,
             ST_X(ubicacion)                  AS longitud,
             precio_corriente::float8         AS precio,
             'COP/galón'                      AS unidad_precio,
             '{}'::text[]                     AS marcas_compatibles,
             NULL::text                       AS tipo_motor,
             activo,
             ST_Distance(ubicacion::geography, ${PUNTO}) AS distancia_m
        FROM estaciones_gasolina
       WHERE activo
         AND ST_DWithin(ubicacion::geography, ${PUNTO}, $3::float8)
         AND ($4::float8 IS NULL OR precio_corriente IS NULL OR precio_corriente <= $4::float8)
       ORDER BY distancia_m
       LIMIT ${LIMITE}`;

    const { rows } = await pool.query(sql, [geo.lng, geo.lat, geo.radio, precio.valor]);
    res.json(rows);
  } catch (err) { next(err); }
});

// ---------- GET /api/v1/puntos-carga ----------
router.get('/puntos-carga', async (req, res, next) => {
  try {
    const geo = leerGeo(req.query);
    if (geo.error) return res.status(400).json({ error: geo.error });
    const marca = textoOpcional(req.query.marca);

    const sql = `
      SELECT id::int AS id,
             'PUNTO_CARGA'                    AS tipo,
             nombre, direccion,
             ST_Y(ubicacion)                  AS latitud,
             ST_X(ubicacion)                  AS longitud,
             precio_kwh::float8               AS precio,
             'COP/kWh'                        AS unidad_precio,
             marcas_compatibles,
             NULL::text                       AS tipo_motor,
             activo,
             ST_Distance(ubicacion::geography, ${PUNTO}) AS distancia_m
        FROM puntos_carga
       WHERE activo
         AND ST_DWithin(ubicacion::geography, ${PUNTO}, $3::float8)
         AND ($4::text IS NULL
              OR marcas_compatibles = '{}'
              OR lower($4::text) = ANY (SELECT lower(m) FROM unnest(marcas_compatibles) AS m))
       ORDER BY distancia_m
       LIMIT ${LIMITE}`;

    const { rows } = await pool.query(sql, [geo.lng, geo.lat, geo.radio, marca]);
    res.json(rows);
  } catch (err) { next(err); }
});

// ---------- GET /api/v1/talleres ----------
router.get('/talleres', async (req, res, next) => {
  try {
    const geo = leerGeo(req.query);
    if (geo.error) return res.status(400).json({ error: geo.error });

    const tipoMotor = textoOpcional(req.query.tipo_motor);
    if (tipoMotor && !TIPOS_MOTOR.includes(tipoMotor.toUpperCase())) {
      return res.status(400).json({ error: 'tipo_motor debe ser COMBUSTION, ELECTRICA o AMBOS' });
    }
    const presupuesto = numeroOpcional(req.query.presupuesto_max);
    if (presupuesto.error) return res.status(400).json({ error: 'presupuesto_max debe ser un número positivo' });
    const marca = textoOpcional(req.query.marca);

    const sql = `
      SELECT id::int AS id,
             'TALLER'                         AS tipo,
             nombre, direccion,
             ST_Y(ubicacion)                  AS latitud,
             ST_X(ubicacion)                  AS longitud,
             presupuesto_max::float8          AS precio,
             'COP aprox.'                     AS unidad_precio,
             marcas_compatibles,
             tipo_motor::text                 AS tipo_motor,
             activo,
             ST_Distance(ubicacion::geography, ${PUNTO}) AS distancia_m
        FROM talleres_mecanicos
       WHERE activo
         AND ST_DWithin(ubicacion::geography, ${PUNTO}, $3::float8)
         AND ($4::text IS NULL OR tipo_motor::text = $4::text OR tipo_motor = 'AMBOS')
         AND ($5::float8 IS NULL OR presupuesto_max IS NULL OR presupuesto_max <= $5::float8)
         AND ($6::text IS NULL
              OR marcas_compatibles = '{}'
              OR lower($6::text) = ANY (SELECT lower(m) FROM unnest(marcas_compatibles) AS m))
       ORDER BY distancia_m
       LIMIT ${LIMITE}`;

    const { rows } = await pool.query(sql, [
      geo.lng, geo.lat, geo.radio,
      tipoMotor ? tipoMotor.toUpperCase() : null,
      presupuesto.valor,
      marca,
    ]);
    res.json(rows);
  } catch (err) { next(err); }
});

module.exports = router;
