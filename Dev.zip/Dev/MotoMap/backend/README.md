# MotoMap backend (Node.js + Express + PostGIS)

    cd backend
    npm install
    npm start

Requiere Node 18+ y la base `motomap` ya creada con `database/schema_postgis.sql`.
Configura la conexión en `backend/.env` (DATABASE_URL).

Endpoints de prueba (centro de Bucaramanga):
- http://localhost:8080/health
- http://localhost:8080/api/v1/estaciones-gasolina?lat=7.1193&lng=-73.1227&radio_m=5000
- http://localhost:8080/api/v1/puntos-carga?lat=7.1193&lng=-73.1227&radio_m=10000&marca=Zero
- http://localhost:8080/api/v1/talleres?lat=7.1193&lng=-73.1227&radio_m=5000&tipo_motor=COMBUSTION&presupuesto_max=200000
