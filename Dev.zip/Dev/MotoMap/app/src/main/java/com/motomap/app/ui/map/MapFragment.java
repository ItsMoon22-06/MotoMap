package com.motomap.app.ui.map;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.motomap.app.R;
import com.motomap.app.data.model.LugarMapa;
import com.motomap.app.data.model.ModoVehiculo;
import com.motomap.app.databinding.FragmentMapBinding;
import com.motomap.app.ui.filter.FilterBottomSheetDialog;
import com.motomap.app.viewmodel.MapViewModel;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class MapFragment extends Fragment implements OnMapReadyCallback {

    private static final LatLng UBICACION_POR_DEFECTO = new LatLng(7.1193, -73.1227); // Bucaramanga
    private static final float ZOOM = 14f;

    private FragmentMapBinding binding;
    private MapViewModel viewModel;
    private GoogleMap map;
    private FusedLocationProviderClient fusedClient;

    private final ActivityResultLauncher<String[]> permisosLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                    resultado -> {
                        if (tienePermisoUbicacion()) {
                            habilitarMiUbicacion();
                            obtenerUbicacion();
                        } else {
                            usarUbicacion(UBICACION_POR_DEFECTO);
                        }
                    });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentMapBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(MapViewModel.class);
        fusedClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        SupportMapFragment mapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map_container);
        if (mapFragment != null) mapFragment.getMapAsync(this);

        configurarBotones();
        observarViewModel();
    }

    // ------------------------------------------------------------------
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        map.getUiSettings().setZoomControlsEnabled(false);
        map.getUiSettings().setMapToolbarEnabled(false);
        map.setOnInfoWindowClickListener(marker -> {
            Object tag = marker.getTag();
            if (tag instanceof LugarMapa) viewModel.toggleFavorito((LugarMapa) tag);
        });

        if (tienePermisoUbicacion()) {
            habilitarMiUbicacion();
            obtenerUbicacion();
        } else {
            permisosLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        }
        dibujarMarcadores(viewModel.getLugares().getValue());
    }

    private void configurarBotones() {
        binding.fabFiltros.setOnClickListener(v ->
                new FilterBottomSheetDialog()
                        .show(getChildFragmentManager(), FilterBottomSheetDialog.TAG));

        binding.fabMiUbicacion.setOnClickListener(v -> {
            if (tienePermisoUbicacion()) obtenerUbicacion();
            else permisosLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        });

        binding.btnBuscarZona.setOnClickListener(v -> {
            if (map == null) return;
            viewModel.actualizarUbicacion(map.getCameraPosition().target);
            viewModel.buscar();
        });
    }

    private void observarViewModel() {
        viewModel.getLugares().observe(getViewLifecycleOwner(), this::dibujarMarcadores);

        viewModel.getCargando().observe(getViewLifecycleOwner(), c ->
                binding.progress.setVisibility(Boolean.TRUE.equals(c) ? View.VISIBLE : View.GONE));

        viewModel.getDesdeCache().observe(getViewLifecycleOwner(), cache -> {
            if (Boolean.TRUE.equals(cache)) {
                Toast.makeText(requireContext(), R.string.datos_cache, Toast.LENGTH_SHORT).show();
            }
        });

        viewModel.getMensaje().observe(getViewLifecycleOwner(), msg -> {
            if (msg != null) {
                Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
                viewModel.consumirMensaje();
            }
        });

        // Resumen de filtros activos en el chip superior
        viewModel.getModo().observe(getViewLifecycleOwner(), m -> actualizarResumen());
        viewModel.getPresupuestoMax().observe(getViewLifecycleOwner(), p -> actualizarResumen());
        viewModel.getMarca().observe(getViewLifecycleOwner(), m -> actualizarResumen());
    }

    private void actualizarResumen() {
        if (binding == null) return;
        ModoVehiculo modo = viewModel.getModo().getValue();
        String texto;
        if (modo == ModoVehiculo.ELECTRICA) {
            String marca = viewModel.getMarca().getValue();
            texto = (marca == null || marca.isEmpty())
                    ? getString(R.string.resumen_electrica_sin)
                    : getString(R.string.resumen_electrica, marca);
        } else {
            Double max = viewModel.getPresupuestoMax().getValue();
            texto = (max == null)
                    ? getString(R.string.resumen_combustion_sin)
                    : getString(R.string.resumen_combustion, formatearPrecio(max));
        }
        binding.chipResumen.setText(texto);
    }

    // ------------------------------------------------------------------
    private void dibujarMarcadores(@Nullable List<LugarMapa> lugares) {
        if (map == null) return;
        map.clear();
        if (lugares == null) return;

        for (LugarMapa l : lugares) {
            Marker marker = map.addMarker(new MarkerOptions()
                    .position(new LatLng(l.getLatitud(), l.getLongitud()))
                    .title(l.getNombre())
                    .snippet(construirSnippet(l))
                    .icon(BitmapDescriptorFactory.defaultMarker(colorPorTipo(l))));
            if (marker != null) marker.setTag(l);
        }
    }

    private float colorPorTipo(LugarMapa l) {
        if (l.getTipo() == null) return BitmapDescriptorFactory.HUE_RED;
        switch (l.getTipo()) {
            case ESTACION_GASOLINA: return BitmapDescriptorFactory.HUE_ORANGE;
            case PUNTO_CARGA:       return BitmapDescriptorFactory.HUE_GREEN;
            case TALLER:
            default:                return BitmapDescriptorFactory.HUE_AZURE;
        }
    }

    private String construirSnippet(LugarMapa l) {
        StringBuilder sb = new StringBuilder();
        if (l.getDireccion() != null) sb.append(l.getDireccion());
        if (l.getPrecio() != null) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(formatearPrecio(l.getPrecio()));
            if (l.getUnidadPrecio() != null) sb.append(' ').append(l.getUnidadPrecio());
        }
        sb.append("\n(toca para favorito)");
        return sb.toString();
    }

    private String formatearPrecio(double valor) {
        return NumberFormat.getCurrencyInstance(new Locale("es", "CO")).format(valor);
    }

    // ------------------------------------------------------------------
    private boolean tienePermisoUbicacion() {
        return ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void habilitarMiUbicacion() {
        if (map != null) map.setMyLocationEnabled(true);
    }

    @SuppressLint("MissingPermission")
    private void obtenerUbicacion() {
        fusedClient.getLastLocation().addOnSuccessListener(requireActivity(), loc -> {
            if (binding == null) return;
            usarUbicacion(loc != null
                    ? new LatLng(loc.getLatitude(), loc.getLongitude())
                    : UBICACION_POR_DEFECTO);
        });
    }

    private void usarUbicacion(LatLng punto) {
        viewModel.actualizarUbicacion(punto);
        if (map != null) map.animateCamera(CameraUpdateFactory.newLatLngZoom(punto, ZOOM));
        viewModel.buscar();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        map = null;
        binding = null;
    }
}
