package com.motomap.app.ui.filter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.motomap.app.R;
import com.motomap.app.data.model.ModoVehiculo;
import com.motomap.app.databinding.BottomSheetFilterBinding;
import com.motomap.app.viewmodel.MapViewModel;

public class FilterBottomSheetDialog extends BottomSheetDialogFragment {

    public static final String TAG = "FilterBottomSheet";

    private BottomSheetFilterBinding binding;
    private MapViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = BottomSheetFilterBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(requireActivity()).get(MapViewModel.class);

        binding.actMarca.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                getResources().getStringArray(R.array.marcas_motos)));

        // Estado actual
        ModoVehiculo modo = viewModel.getModo().getValue();
        if (modo == null) modo = ModoVehiculo.COMBUSTION;
        binding.toggleModo.check(modo == ModoVehiculo.ELECTRICA
                ? R.id.btnElectrica : R.id.btnCombustion);

        Double presupuesto = viewModel.getPresupuestoMax().getValue();
        if (presupuesto != null) binding.etPresupuesto.setText(String.valueOf(presupuesto.longValue()));

        String marca = viewModel.getMarca().getValue();
        if (marca != null) binding.actMarca.setText(marca, false);

        actualizarVisibilidad(modo);

        binding.toggleModo.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (isChecked) actualizarVisibilidad(modoSeleccionado());
        });

        binding.btnAplicar.setOnClickListener(v -> aplicar());
    }

    private ModoVehiculo modoSeleccionado() {
        return binding.toggleModo.getCheckedButtonId() == R.id.btnElectrica
                ? ModoVehiculo.ELECTRICA : ModoVehiculo.COMBUSTION;
    }

    private void actualizarVisibilidad(ModoVehiculo modo) {
        boolean electrica = modo == ModoVehiculo.ELECTRICA;
        binding.layoutPresupuesto.setVisibility(electrica ? View.GONE : View.VISIBLE);
        binding.layoutMarca.setVisibility(electrica ? View.VISIBLE : View.GONE);
    }

    private void aplicar() {
        ModoVehiculo modo = modoSeleccionado();

        Double presupuesto = null;
        CharSequence txt = binding.etPresupuesto.getText();
        if (txt != null && txt.toString().trim().length() > 0) {
            try {
                presupuesto = Double.parseDouble(txt.toString().trim());
            } catch (NumberFormatException ignored) { /* inputType=number lo evita */ }
        }

        String marca = binding.actMarca.getText() != null
                ? binding.actMarca.getText().toString().trim() : "";
        if (marca.isEmpty()) marca = null;

        viewModel.aplicarFiltros(modo, presupuesto, marca);
        dismiss();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
