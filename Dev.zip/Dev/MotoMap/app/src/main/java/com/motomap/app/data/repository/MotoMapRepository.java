package com.motomap.app.data.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import com.motomap.app.data.local.AppDatabase;
import com.motomap.app.data.local.FavoritoEntity;
import com.motomap.app.data.local.FavoritosDao;
import com.motomap.app.data.local.UbicacionCacheDao;
import com.motomap.app.data.local.UbicacionCacheEntity;
import com.motomap.app.data.model.FiltroMapa;
import com.motomap.app.data.model.LugarMapa;
import com.motomap.app.data.model.ModoVehiculo;
import com.motomap.app.data.model.TipoLugar;
import com.motomap.app.data.remote.ApiService;
import com.motomap.app.data.remote.RetrofitClient;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Response;

/**
 * Única fuente de verdad: intenta la API (Retrofit), guarda en Room
 * y, si no hay red, responde desde la caché local.
 */
public class MotoMapRepository {

    private static final long CACHE_TTL_MS = 7L * 24 * 60 * 60 * 1000; // 7 días

    public interface Callback<T> {
        /** Siempre se invoca en el hilo principal. */
        void onResult(T data, boolean desdeCache);
        void onError(String mensaje);
    }

    private final ApiService api;
    private final FavoritosDao favoritosDao;
    private final UbicacionCacheDao cacheDao;
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());

    public MotoMapRepository(Context context) {
        AppDatabase db = AppDatabase.getInstance(context);
        this.api = RetrofitClient.getApiService();
        this.favoritosDao = db.favoritosDao();
        this.cacheDao = db.ubicacionCacheDao();
    }

    // ------------------------------------------------------------------
    // Búsqueda remota con sincronización a Room
    // ------------------------------------------------------------------
    public void buscarLugares(FiltroMapa f, Callback<List<LugarMapa>> cb) {
        io.execute(() -> {
            try {
                List<LugarMapa> resultado = new ArrayList<>();
                if (f.getModo() == ModoVehiculo.COMBUSTION) {
                    resultado.addAll(ejecutar(api.getEstaciones(
                            f.getLatitud(), f.getLongitud(), f.getRadioMetros(),
                            f.getPresupuestoMax())));
                    resultado.addAll(ejecutar(api.getTalleres(
                            f.getLatitud(), f.getLongitud(), f.getRadioMetros(),
                            "COMBUSTION", f.getPresupuestoMax(), null)));
                } else {
                    resultado.addAll(ejecutar(api.getPuntosCarga(
                            f.getLatitud(), f.getLongitud(), f.getRadioMetros(),
                            f.getMarca())));
                    resultado.addAll(ejecutar(api.getTalleres(
                            f.getLatitud(), f.getLongitud(), f.getRadioMetros(),
                            "ELECTRICA", null, f.getMarca())));
                }

                cacheDao.insertarTodos(aEntidades(resultado));
                cacheDao.eliminarAntiguos(System.currentTimeMillis() - CACHE_TTL_MS);
                main.post(() -> cb.onResult(resultado, false));

            } catch (IOException e) {
                List<LugarMapa> cache = leerCache(f);
                if (cache.isEmpty()) {
                    main.post(() -> cb.onError("Sin conexión y sin datos guardados en esta zona"));
                } else {
                    main.post(() -> cb.onResult(cache, true));
                }
            }
        });
    }

    private List<LugarMapa> ejecutar(Call<List<LugarMapa>> call) throws IOException {
        Response<List<LugarMapa>> r = call.execute();
        if (!r.isSuccessful() || r.body() == null) {
            throw new IOException("HTTP " + r.code());
        }
        return r.body();
    }

    // ------------------------------------------------------------------
    // Caché offline
    // ------------------------------------------------------------------
    private List<LugarMapa> leerCache(FiltroMapa f) {
        double[] bb = boundingBox(f.getLatitud(), f.getLongitud(), f.getRadioMetros());
        List<UbicacionCacheEntity> filas =
                cacheDao.consultarPorUbicacion(bb[0], bb[1], bb[2], bb[3]);

        List<LugarMapa> salida = new ArrayList<>();
        for (UbicacionCacheEntity e : filas) {
            LugarMapa l = aModelo(e);
            if (cumpleFiltro(l, f)) salida.add(l);
        }
        return salida;
    }

    private boolean cumpleFiltro(LugarMapa l, FiltroMapa f) {
        String motor = l.getTipoMotor();
        if (f.getModo() == ModoVehiculo.COMBUSTION) {
            boolean esCombustion = l.getTipo() == TipoLugar.ESTACION_GASOLINA
                    || (l.getTipo() == TipoLugar.TALLER
                        && ("COMBUSTION".equals(motor) || "AMBOS".equals(motor)));
            if (!esCombustion) return false;
            Double max = f.getPresupuestoMax();
            return max == null || l.getPrecio() == null || l.getPrecio() <= max;
        } else {
            boolean esElectrico = l.getTipo() == TipoLugar.PUNTO_CARGA
                    || (l.getTipo() == TipoLugar.TALLER
                        && ("ELECTRICA".equals(motor) || "AMBOS".equals(motor)));
            if (!esElectrico) return false;
            String marca = f.getMarca();
            if (marca == null || marca.isEmpty() || l.getMarcasCompatibles().isEmpty()) return true;
            for (String m : l.getMarcasCompatibles()) {
                if (m.equalsIgnoreCase(marca)) return true;
            }
            return false;
        }
    }

    private List<UbicacionCacheEntity> aEntidades(List<LugarMapa> lugares) {
        long ahora = System.currentTimeMillis();
        List<UbicacionCacheEntity> out = new ArrayList<>();
        for (LugarMapa l : lugares) {
            UbicacionCacheEntity e = new UbicacionCacheEntity();
            e.clave = l.getTipo().name() + ":" + l.getId();
            e.tipo = l.getTipo().name();
            e.remoteId = l.getId();
            e.nombre = l.getNombre() != null ? l.getNombre() : "";
            e.direccion = l.getDireccion();
            e.latitud = l.getLatitud();
            e.longitud = l.getLongitud();
            e.precio = l.getPrecio();
            e.unidadPrecio = l.getUnidadPrecio();
            e.marcasCompatibles = String.join(",", l.getMarcasCompatibles());
            e.tipoMotor = l.getTipoMotor();
            e.actualizadoEn = ahora;
            out.add(e);
        }
        return out;
    }

    private LugarMapa aModelo(UbicacionCacheEntity e) {
        List<String> marcas = (e.marcasCompatibles == null || e.marcasCompatibles.isEmpty())
                ? new ArrayList<>()
                : new ArrayList<>(Arrays.asList(e.marcasCompatibles.split(",")));
        return new LugarMapa(e.remoteId, TipoLugar.valueOf(e.tipo), e.nombre, e.direccion,
                e.latitud, e.longitud, e.precio, e.unidadPrecio, marcas, e.tipoMotor, true);
    }

    // ------------------------------------------------------------------
    // Favoritos
    // ------------------------------------------------------------------
    public LiveData<List<FavoritoEntity>> observarFavoritos() {
        return favoritosDao.observarTodos();
    }

    public void favoritosCercanos(double lat, double lng, int radioM,
                                  Callback<List<FavoritoEntity>> cb) {
        io.execute(() -> {
            double[] bb = boundingBox(lat, lng, radioM);
            List<FavoritoEntity> lista = favoritosDao.consultarPorUbicacion(bb[0], bb[1], bb[2], bb[3]);
            main.post(() -> cb.onResult(lista, true));
        });
    }

    /** Agrega o quita el favorito. onResult(data = true si quedó agregado). */
    public void toggleFavorito(LugarMapa lugar, Callback<Boolean> cb) {
        io.execute(() -> {
            String tipo = lugar.getTipo().name();
            boolean agregado;
            if (favoritosDao.existe(tipo, lugar.getId()) > 0) {
                favoritosDao.eliminarPorRemoto(tipo, lugar.getId());
                agregado = false;
            } else {
                FavoritoEntity f = new FavoritoEntity();
                f.tipo = tipo;
                f.remoteId = lugar.getId();
                f.nombre = lugar.getNombre() != null ? lugar.getNombre() : "";
                f.direccion = lugar.getDireccion();
                f.latitud = lugar.getLatitud();
                f.longitud = lugar.getLongitud();
                f.creadoEn = System.currentTimeMillis();
                favoritosDao.insertar(f);
                agregado = true;
            }
            final boolean res = agregado;
            main.post(() -> cb.onResult(res, false));
        });
    }

    // ------------------------------------------------------------------
    // Utilidad geoespacial: rectángulo aproximado alrededor de un punto
    // ------------------------------------------------------------------
    private static double[] boundingBox(double lat, double lng, int radioM) {
        double dLat = radioM / 111_320.0;
        double dLng = radioM / (111_320.0 * Math.max(0.01, Math.cos(Math.toRadians(lat))));
        return new double[]{lat - dLat, lat + dLat, lng - dLng, lng + dLng};
    }
}
