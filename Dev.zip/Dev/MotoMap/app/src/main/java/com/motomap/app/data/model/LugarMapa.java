package com.motomap.app.data.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/** POJO unificado: lo que devuelve la API y lo que se pinta en el mapa. */
public class LugarMapa {

    @SerializedName("id")                 private long id;
    @SerializedName("tipo")               private TipoLugar tipo;
    @SerializedName("nombre")             private String nombre;
    @SerializedName("direccion")          private String direccion;
    @SerializedName("latitud")            private double latitud;
    @SerializedName("longitud")           private double longitud;
    @SerializedName("precio")             private Double precio;
    @SerializedName("unidad_precio")      private String unidadPrecio;
    @SerializedName("marcas_compatibles") private List<String> marcasCompatibles = new ArrayList<>();
    @SerializedName("tipo_motor")         private String tipoMotor;   // COMBUSTION | ELECTRICA | AMBOS | null
    @SerializedName("activo")             private boolean activo = true;
    @SerializedName("distancia_m")        private Double distanciaMetros;

    public LugarMapa() { }

    public LugarMapa(long id, TipoLugar tipo, String nombre, String direccion,
                     double latitud, double longitud, Double precio, String unidadPrecio,
                     List<String> marcas, String tipoMotor, boolean activo) {
        this.id = id; this.tipo = tipo; this.nombre = nombre; this.direccion = direccion;
        this.latitud = latitud; this.longitud = longitud; this.precio = precio;
        this.unidadPrecio = unidadPrecio;
        this.marcasCompatibles = marcas != null ? marcas : new ArrayList<>();
        this.tipoMotor = tipoMotor; this.activo = activo;
    }

    public long getId() { return id; }
    public TipoLugar getTipo() { return tipo; }
    public String getNombre() { return nombre; }
    public String getDireccion() { return direccion; }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public Double getPrecio() { return precio; }
    public String getUnidadPrecio() { return unidadPrecio; }
    public List<String> getMarcasCompatibles() {
        return marcasCompatibles != null ? marcasCompatibles : new ArrayList<>();
    }
    public String getTipoMotor() { return tipoMotor; }
    public boolean isActivo() { return activo; }
    public Double getDistanciaMetros() { return distanciaMetros; }
}
