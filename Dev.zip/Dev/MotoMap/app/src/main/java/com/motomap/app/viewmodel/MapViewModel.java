package com.motomap.app.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.maps.model.LatLng;
import com.motomap.app.data.local.FavoritoEntity;
import com.motomap.app.data.model.FiltroMapa;
import com.motomap.app.data.model.LugarMapa;
import com.motomap.app.data.model.ModoVehiculo;
import com.motomap.app.data.repository.MotoMapRepository;

import java.util.ArrayList;
import java.util.List;

/** Estado de la UI del mapa + filtros seleccionados. Compartido Activity/Fragment/BottomSheet. */
public class MapViewModel extends AndroidViewModel {

    private static final int RADIO_DEFAULT_M = 5000;

    private final MotoMapRepository repository;

    // --- Filtros ---
    private final MutableLiveData<ModoVehiculo> modo = new MutableLiveData<>(ModoVehiculo.COMBUSTION);
    private final MutableLiveData<Double> presupuestoMax = new MutableLiveData<>();   // combustión
    private final MutableLiveData<String> marca = new MutableLiveData<>();            // eléctrica
    private final MutableLiveData<Integer> radioMetros = new MutableLiveData<>(RADIO_DEFAULT_M);

    // --- Estado ---
    private final MutableLiveData<LatLng> ubicacion = new MutableLiveData<>();
    private final MutableLiveData<List<LugarMapa>> lugares = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<Boolean> cargando = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> desdeCache = new MutableLiveData<>(false);
    private final MutableLiveData<String> mensaje = new MutableLiveData<>();           // evento one-shot

    private final LiveData<List<FavoritoEntity>> favoritos;

    public MapViewModel(@NonNull Application application) {
        super(application);
        repository = new MotoMapRepository(application);
        favoritos = repository.observarFavoritos();
    }

    // ---------------- Getters (solo lectura para la UI) ----------------
    public LiveData<ModoVehiculo> getModo() { return modo; }
    public LiveData<Double> getPresupuestoMax() { return presupuestoMax; }
    public LiveData<String> getMarca() { return marca; }
    public LiveData<Integer> getRadioMetros() { return radioMetros; }
    public LiveData<LatLng> getUbicacion() { return ubicacion; }
    public LiveData<List<LugarMapa>> getLugares() { return lugares; }
    public LiveData<Boolean> getCargando() { return cargando; }
    public LiveData<Boolean> getDesdeCache() { return desdeCache; }
    public LiveData<String> getMensaje() { return mensaje; }
    public LiveData<List<FavoritoEntity>> getFavoritos() { return favoritos; }

    // ---------------- Acciones ----------------
    public void actualizarUbicacion(LatLng nueva) {
        ubicacion.setValue(nueva);
    }

    public void setModo(ModoVehiculo nuevo) {
        modo.setValue(nuevo);
    }

    /** Aplica filtros y relanza la búsqueda. Limpia el filtro que no aplica al modo. */
    public void aplicarFiltros(ModoVehiculo nuevoModo, Double presupuesto, String marcaMoto) {
        modo.setValue(nuevoModo);
        if (nuevoModo == ModoVehiculo.COMBUSTION) {
            presupuestoMax.setValue(presupuesto);
            marca.setValue(null);
        } else {
            marca.setValue(marcaMoto);
            presupuestoMax.setValue(null);
        }
        buscar();
    }

    public void buscar() {
        LatLng u = ubicacion.getValue();
        ModoVehiculo m = modo.getValue();
        if (u == null || m == null) {
            mensaje.setValue("Ubicación no disponible");
            return;
        }
        Integer radio = radioMetros.getValue();
        FiltroMapa filtro = new FiltroMapa(m, u.latitude, u.longitude,
                radio != null ? radio : RADIO_DEFAULT_M,
                presupuestoMax.getValue(), marca.getValue());

        cargando.setValue(true);
        repository.buscarLugares(filtro, new MotoMapRepository.Callback<List<LugarMapa>>() {
            @Override
            public void onResult(List<LugarMapa> data, boolean cache) {
                cargando.setValue(false);
                desdeCache.setValue(cache);
                lugares.setValue(data);
            }

            @Override
            public void onError(String msg) {
                cargando.setValue(false);
                lugares.setValue(new ArrayList<>());
                mensaje.setValue(msg);
            }
        });
    }

    public void toggleFavorito(LugarMapa lugar) {
        repository.toggleFavorito(lugar, new MotoMapRepository.Callback<Boolean>() {
            @Override
            public void onResult(Boolean agregado, boolean cache) {
                mensaje.setValue(agregado ? "Agregado a favoritos" : "Quitado de favoritos");
            }

            @Override
            public void onError(String msg) {
                mensaje.setValue(msg);
            }
        });
    }

    /** Llamar después de mostrar el mensaje para no repetirlo al rotar la pantalla. */
    public void consumirMensaje() {
        mensaje.setValue(null);
    }
}
