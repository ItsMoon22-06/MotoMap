package com.motomap.app.data.remote;

import com.motomap.app.data.model.LugarMapa;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/** Los parámetros null NO se envían (Retrofit los omite). */
public interface ApiService {

    @GET("api/v1/estaciones-gasolina")
    Call<List<LugarMapa>> getEstaciones(
            @Query("lat") double lat,
            @Query("lng") double lng,
            @Query("radio_m") int radioMetros,
            @Query("precio_max") Double precioMax);

    @GET("api/v1/puntos-carga")
    Call<List<LugarMapa>> getPuntosCarga(
            @Query("lat") double lat,
            @Query("lng") double lng,
            @Query("radio_m") int radioMetros,
            @Query("marca") String marca);

    @GET("api/v1/talleres")
    Call<List<LugarMapa>> getTalleres(
            @Query("lat") double lat,
            @Query("lng") double lng,
            @Query("radio_m") int radioMetros,
            @Query("tipo_motor") String tipoMotor,
            @Query("presupuesto_max") Double presupuestoMax,
            @Query("marca") String marca);
}
