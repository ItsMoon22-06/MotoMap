package com.motomap.app.data.local;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface FavoritosDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertar(FavoritoEntity favorito);

    @Query("SELECT * FROM favoritos ORDER BY creado_en DESC")
    LiveData<List<FavoritoEntity>> observarTodos();

    /** Consulta por ubicación: favoritos dentro de un rectángulo (bounding box). */
    @Query("SELECT * FROM favoritos " +
           "WHERE latitud BETWEEN :latMin AND :latMax " +
           "AND longitud BETWEEN :lngMin AND :lngMax " +
           "ORDER BY nombre")
    List<FavoritoEntity> consultarPorUbicacion(double latMin, double latMax,
                                               double lngMin, double lngMax);

    @Query("SELECT COUNT(*) FROM favoritos WHERE tipo = :tipo AND remote_id = :remoteId")
    int existe(String tipo, long remoteId);

    @Delete
    int eliminar(FavoritoEntity favorito);

    @Query("DELETE FROM favoritos WHERE tipo = :tipo AND remote_id = :remoteId")
    int eliminarPorRemoto(String tipo, long remoteId);

    @Query("DELETE FROM favoritos")
    void eliminarTodos();
}
