package com.motomap.app.data.local;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "favoritos",
        indices = {
                @Index(value = {"tipo", "remote_id"}, unique = true),
                @Index(value = {"latitud", "longitud"})
        })
public class FavoritoEntity {

    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull
    @ColumnInfo(name = "tipo")
    public String tipo = "";             // nombre del enum TipoLugar

    @ColumnInfo(name = "remote_id")
    public long remoteId;

    @NonNull
    @ColumnInfo(name = "nombre")
    public String nombre = "";

    @ColumnInfo(name = "direccion")
    public String direccion;

    @ColumnInfo(name = "latitud")
    public double latitud;

    @ColumnInfo(name = "longitud")
    public double longitud;

    @ColumnInfo(name = "creado_en")
    public long creadoEn;                // epoch millis
}
