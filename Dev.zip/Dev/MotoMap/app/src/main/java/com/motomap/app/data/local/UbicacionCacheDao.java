package com.motomap.app.data.local;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UbicacionCacheDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertarTodos(List<UbicacionCacheEntity> lugares);

    @Query("SELECT * FROM ubicaciones_cache " +
           "WHERE latitud BETWEEN :latMin AND :latMax " +
           "AND longitud BETWEEN :lngMin AND :lngMax")
    List<UbicacionCacheEntity> consultarPorUbicacion(double latMin, double latMax,
                                                     double lngMin, double lngMax);

    @Query("DELETE FROM ubicaciones_cache WHERE actualizado_en < :limite")
    int eliminarAntiguos(long limite);
}
