package com.motomap.app.data.model;

public enum TipoLugar {
    ESTACION_GASOLINA,
    PUNTO_CARGA,
    TALLER
}
