package com.motomap.app.data.local;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** Caché offline de lugares descargados del backend. */
@Entity(
        tableName = "ubicaciones_cache",
        indices = {@Index(value = {"latitud", "longitud"})})
public class UbicacionCacheEntity {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "clave")
    public String clave = "";            // "TIPO:remoteId"

    @NonNull
    @ColumnInfo(name = "tipo")
    public String tipo = "";

    @ColumnInfo(name = "remote_id")
    public long remoteId;

    @NonNull
    @ColumnInfo(name = "nombre")
    public String nombre = "";

    @ColumnInfo(name = "direccion")
    public String direccion;

    @ColumnInfo(name = "latitud")
    public double latitud;

    @ColumnInfo(name = "longitud")
    public double longitud;

    @ColumnInfo(name = "precio")
    public Double precio;

    @ColumnInfo(name = "unidad_precio")
    public String unidadPrecio;

    @ColumnInfo(name = "marcas_compatibles")
    public String marcasCompatibles;     // CSV: "Zero,Niu"

    @ColumnInfo(name = "tipo_motor")
    public String tipoMotor;

    @ColumnInfo(name = "actualizado_en")
    public long actualizadoEn;
}
