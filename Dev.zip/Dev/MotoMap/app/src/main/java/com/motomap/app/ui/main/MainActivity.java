package com.motomap.app.ui.main;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.motomap.app.R;
import com.motomap.app.databinding.ActivityMainBinding;
import com.motomap.app.ui.map.MapFragment;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new MapFragment())
                    .commit();
        }
    }
}
