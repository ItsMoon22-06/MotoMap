package com.motomap.app.data.model;

/** Parámetros de búsqueda enviados al repositorio / API. */
public class FiltroMapa {
    private final ModoVehiculo modo;
    private final double latitud;
    private final double longitud;
    private final int radioMetros;
    private final Double presupuestoMax; // solo COMBUSTION (nullable)
    private final String marca;          // solo ELECTRICA (nullable)

    public FiltroMapa(ModoVehiculo modo, double latitud, double longitud, int radioMetros,
                      Double presupuestoMax, String marca) {
        this.modo = modo;
        this.latitud = latitud;
        this.longitud = longitud;
        this.radioMetros = radioMetros;
        this.presupuestoMax = presupuestoMax;
        this.marca = marca;
    }

    public ModoVehiculo getModo() { return modo; }
    public double getLatitud() { return latitud; }
    public double getLongitud() { return longitud; }
    public int getRadioMetros() { return radioMetros; }
    public Double getPresupuestoMax() { return presupuestoMax; }
    public String getMarca() { return marca; }
}
