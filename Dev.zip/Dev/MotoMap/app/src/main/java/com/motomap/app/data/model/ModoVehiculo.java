package com.motomap.app.data.model;

public enum ModoVehiculo {
    COMBUSTION,
    ELECTRICA
}
